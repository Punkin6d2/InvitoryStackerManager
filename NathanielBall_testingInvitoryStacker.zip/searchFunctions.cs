﻿using invintoryStackerClassesTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using testingInvitoryStacker;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace testingInvitoryStacker
{
    internal class searchFunctions
    {
        /*
        public static bool hasGround()
        {
            return true;
        }
        public static int[] searchForIndex(string[,] array, string target) 
        {
            target = fillX(target, 5);
            int rows = array.GetLength(0); // Number of rows
            int cols = array.GetLength(1); // Number of columns

            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    if (array[i, j] == target)
                    {
                        return new int[] { i, j }; // Return the row and column indices
                    }
                }
            }
            return null; // Element not found
        }*/

    }
}
